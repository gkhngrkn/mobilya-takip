import { useState } from 'react'; import { useRouter } from 'next/router'; import { supabase } from '../lib/supabaseClient';
export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();
  const handleLogin = async () => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) alert('Giriş hatası: ' + error.message);
    else router.push('/');
  };
  return (<div><input placeholder="Email" onChange={e => setEmail(e.target.value)} />
    <input type="password" placeholder="Şifre" onChange={e => setPassword(e.target.value)} />
    <button onClick={handleLogin}>Giriş Yap</button></div>);
}