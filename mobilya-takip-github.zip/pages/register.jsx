import { useState } from 'react'; import { useRouter } from 'next/router'; import { supabase } from '../lib/supabaseClient';
export default function Register() {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [role, setRole] = useState('personel');
  const router = useRouter();
  const handleRegister = async () => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (!error && data?.user) {
      await supabase.from('user_roles').insert([{ user_id: data.user.id, role }]);
      router.push('/login');
    } else if (error) alert(error.message);
  };
  return (<div><input placeholder="Email" onChange={e => setEmail(e.target.value)} />
    <input type="password" placeholder="Şifre" onChange={e => setPassword(e.target.value)} />
    <select onChange={e => setRole(e.target.value)}><option value="personel">Personel</option><option value="admin">Admin</option></select>
    <button onClick={handleRegister}>Kayıt Ol</button></div>);
}